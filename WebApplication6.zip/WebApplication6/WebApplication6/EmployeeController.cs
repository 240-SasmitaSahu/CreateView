﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication6
{
    public class EmployeeController : Controller
    {
        public string Index()
        {
            return "Employee default";
        }
        public string FirstName()
        {
            return "Sasmita";
        }
        public string LastName()
        {
            return "Sahu";
        }
    }
}
